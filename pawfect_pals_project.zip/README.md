# 🐾 Pawfect Pals – Pet Accessories Store

Welcome to **Pawfect Pals**, a dropshipping pet store for adorable and affordable cat & dog accessories! 🐶🐱

This is a clean, responsive, and beginner-friendly eCommerce site built with HTML, CSS, and JavaScript — perfect for launching a pet brand with zero hosting costs using **GitHub Pages**.

---

## 🌟 Features

- ✅ Fully responsive design  
- ✅ Product showcase layout  
- ✅ About Us & Contact sections  
- ✅ “Buy Now” buttons (ready for Razorpay/PayPal integration)  
- ✅ Free hosting with GitHub Pages

---

## 📦 Demo

🔗 **Live Website**: [https://yourusername.github.io/pawfect-pals/](https://yourusername.github.io/pawfect-pals/)

*(Replace with your actual GitHub Pages URL)*

---

## 🧱 Built With

- HTML5  
- CSS3  
- JavaScript  
- GitHub Pages (for hosting)

---

## 📥 How to Use

1. Clone this repository or download the ZIP  
2. Open `index.html` in your browser  
3. Customize text, images, and products  
4. Upload to GitHub to host your own store!

---

## 📧 Contact

**Email:** hello@pawfectpals.in  
**Instagram:** [@pawfectpals_store](https://instagram.com)

---

## 📄 License

This project is open-source and free to use.
